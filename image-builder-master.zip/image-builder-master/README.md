This builds Windows 2016/2019/2019 CORE images using [Packer](https://www.packer.io/). Build system requires connectivity to a vCenter with at least one ESXi host running ESXi version 6.7+ and having a datastore big enough to hold installation ISO files and resulting VM images (200GB shoudl be enough).

# Preparation

On Linux box install [packer 1.7.0+](https://www.packer.io/), [packer-provisioner-windows-update plugin 0.11.0+](https://github.com/rgl/packer-provisioner-windows-update), [ovftool](https://code.vmware.com/web/tool/4.4.0/ovf) and [govc v0.24.0](https://github.com/vmware/govmomi). Windows Subsystem for Linux (wsl) can be used instead of Linux machine.

* Obtain latest Windows 2016 and Windows 2019 installation ISO images.  
* Download latest RedHat 7 and RedHat 8 installation ISO images from RedHat.
* Download latest VMware tools for Windows installation ISO image from VMware.

Place all ISOs from above list into `iso` directory inside ESXi server datastore. Adjust `vsphere_iso_url` and `vsphere_tools_iso_url` user variables defined in each packer template to match respective ISO file location and name.

Prepare `secrets` file. Run thie following command from package root directory (modify with actual values):

```bash
cat >secrets <<'EOF'
# This file can be sourced by bash or included by make.
# Don't use single and double quotes in this file.
# Use backslash instead to escape any special characters.
export GOVC_INSECURE=1
export GOVC_HOST=X.X.X.X
export GOVC_URL=https://${GOVC_HOST}/sdk
export GOVC_USERNAME=administrator@vsphere.local
export GOVC_PASSWORD=MySecretPassword
export GOVC_DATACENTER=DatacenterName
export GOVC_CLUSTER=ClusterName
export GOVC_DATASTORE=DatastoreName
export VSPHERE_ESXI_HOST=Y.Y.Y.Y
export VSPHERE_TEMPLATE_FOLDER=Templates
export VSPHERE_VLAN=VM\ Network
EOF
```

# Usage

Run `make help` to get list of all available targets

To build an image (for example Windows 2019) run the following command:

```bash
make build-windows-2019-amd64
```
Build results will be placed into `outputs` directory.

Use `cleanup-*` targets to clean up environment from build results and any temporary files.
