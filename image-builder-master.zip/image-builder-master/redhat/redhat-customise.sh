#!/bin/bash -eux

unregister() {
  last_command_status=$?
  subscription-manager unregister

  if [[ ${last_command_status} -ne 0 ]]; then
    exit 1
  fi
}

echo "==> Setting proxy"
source /tmp/env
[[ ! -z ${GLPC_HTTP_PROXY:-} ]] && export http_proxy=${GLPC_HTTP_PROXY}
[[ ! -z ${GLPC_HTTPS_PROXY:-} ]] && export https_proxy=${GLPC_HTTPS_PROXY}

echo "==> Setting hostname"
source /etc/os-release
HOSTNAME="redhat-$(echo ${VERSION_ID} | tr '.' '-')"
REV=$(echo ${VERSION_ID} | cut -f1 -d.)
[[ $(dmidecode | grep -i vmware) ]] && hostname ${HOSTNAME}-esx || hostname ${HOSTNAME}-kvm
systemctl disable firewalld --now

mkdir /media/dvd
mount /dev/sr0 /media/dvd

[[ ${REV} -eq 7 ]] && cat << EOF > /etc/yum.repos.d/dvd.repo
[InstallMedia]
name=DVD for RHEL7 Server
gpgcheck=1
enabled=1
baseurl=file:///media/dvd/
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-redhat-release
EOF

[[ ${REV} -eq 8 ]] && cat << EOF > /etc/yum.repos.d/dvd.repo
[dvd-BaseOS]
name=DVD for RHEL8 - BaseOS
baseurl=file:///media/dvd/BaseOS
enabled=1
gpgcheck=1
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-redhat-release

[dvd-AppStream]
name=DVD for RHEL8 - AppStream
baseurl=file:///media/dvd/AppStream
enabled=1
gpgcheck=1
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-redhat-release
EOF

[[ ${REV} -eq 8 ]] && yum install -y python3
yum install -y curl cloud-init cloud-utils-growpart wget git

rm /etc/yum.repos.d/dvd.repo
umount /media/dvd
rmdir /media/dvd

if [[ ! $(dmidecode | grep -i vmware) ]]
then
  echo "==> Bundle SCSI Drivers for VMware"
  echo 'add_drivers+=" vmxnet3 virtio_blk mptscsih mptspi scsi_transport_spi vmw_pvscsi "' >> /etc/dracut.conf.d/vmw.conf
  dracut --regenerate-all --force -v
  rm -f /boot/vmlinuz-0-rescue*
  rm -f /boot/initramfs-0-rescue*
  [[ ${REV} -eq 7 ]] && /etc/kernel/postinst.d/51-dracut-rescue-postinst.sh "$(uname -r)" /boot/vmlinuz-"$(uname -r)"
  [[ ${REV} -eq 8 ]] && /usr/lib/kernel/install.d/51-dracut-rescue.install add "$(uname -r)" "" /lib/modules/"$(uname -r)"/vmlinuz
fi

echo "==> Disable root login"
usermod --shell /sbin/nologin root

echo "==> Cleaning up yum/dnf cache"
rm -rf /var/cache/yum

echo "==> Cleaning up tmp"
rm -rf /tmp/*
rm -rf /var/tmp/*

# Need to be improved with something like zerofree or fstrim?
echo "==> Zeroing Disk"
set +e
dd if=/dev/zero of=/zerofile bs=1M
set -e

echo "==> Final cleanup"
rm -f /zerofile
sync

echo "==> Remove the root user shell history"
rm -f ~root/.bash_history
unset HISTFILE
